ALTER TABLE /*_*/content_models
  MODIFY model_id INT AUTO_INCREMENT NOT NULL;
