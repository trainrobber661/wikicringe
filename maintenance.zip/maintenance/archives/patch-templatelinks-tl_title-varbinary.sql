ALTER TABLE /*_*/templatelinks MODIFY tl_title VARBINARY(255) NOT NULL default '';
