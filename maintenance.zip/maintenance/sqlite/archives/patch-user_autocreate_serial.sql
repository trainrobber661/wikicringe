CREATE TABLE /*_*/user_autocreate_serial (
  uas_shard INTEGER UNSIGNED NOT NULL,
  uas_value INTEGER UNSIGNED NOT NULL,
  PRIMARY KEY(uas_shard)
);
