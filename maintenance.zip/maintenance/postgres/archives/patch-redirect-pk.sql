ALTER TABLE redirect ADD PRIMARY KEY (rd_from);
