// Expose via module.exports
module.exports = window.pluralRuleParser;

// Back-compat: Also expose via mw.lib
mw.libs.pluralRuleParser = window.pluralRuleParser;
