module.exports = require( './specialcharacters.json' );
