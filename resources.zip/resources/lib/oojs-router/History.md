# OOjs Router Release History

## v0.3.0 / 2021-09-09
* [BREAKING CHANGE] Require OOjs v6.0.0, up from v2.0.0 (James D. Forrester)
* [BREAKING CHANGE] Require jQuery v3.6.0, up from v3.3.1 (James D. Forrester)

## v0.2.0 / 2019-02-06
* Add OO.Router `navigateTo()` method for accessing replaceState (Jon Robson)
* build: Add AUTHORS.txt to package manifest (James D. Forrester)

## v0.1.0 / 2016-05-05
* Initial commit (Jon Robson)
* Add build, CI infrastructure (James D. Forrester)
