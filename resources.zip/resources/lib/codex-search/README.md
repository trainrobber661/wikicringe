# Codex-search

This package is a subset of the `@wikimedia/codex` package, containing only the CdxTypeaheadSearch
component. It's only intended for use in MediaWiki; do not use this package elsewhere.
Use the `@wikimedia/codex` package instead.